

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;

/**
 * Servlet implementation class UploadSer
 */
@WebServlet("/UploadSer")
public class UploadSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UploadSer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter(); 
		
		
        
        try
		{
        	
    		response.setContentType("text/html");
    		MultipartRequest m=new MultipartRequest(request,getServletContext().getRealPath("/")+"upload");
    		out.print(m.getFilesystemName("file")+"<br>");
    		out.print(m.getContentType("file")+"<br>");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectcrm","root","");
			Statement st = con.createStatement();
			int x = st.executeUpdate("insert into imgupload(path) values('"+m.getFilesystemName("file")+"')");
			if(x!=0)
			{
				response.sendRedirect("fileupload.jsp");
				//out.print("File uploaded Successfully");
			}
			con.close();
		}
		catch(Exception ex)
		{
			out.print(ex.getMessage().toString());
		}
	}

}
